import React, { Component } from 'react';

class HomePage extends Component {  
  render() {
    return (
      <div>Hello world! This is the home page route.</div>
    );
  }
}

export default HomePage; 