import React, { Component } from 'react';  
import { connect } from 'react-redux';  
import { Field, reduxForm } from 'redux-form';  
import { registerUser } from '../../actions';
//import { styles } from '../../public';

const form = reduxForm({  
  form: 'register',
  validate
});

const renderField = field => (  
    <div>
      <input className="form-control" {...field.input}/>
      {field.touched && field.error && <div className="error">{field.error}</div>}
    </div>
);

function validate(formProps) {  
  const errors = {};

  if (!formProps.firstName) {
    errors.firstName = 'Please enter a full name';
  }
  

  if (!formProps.email ) {
    errors.email = 'Please enter an email';
  }

  if (!formProps.password) {
    errors.password = 'Please enter a password';
  }
  if (!formProps.contact) {
    errors.contact = 'Please enter an contact';
  }
  if (!formProps.branch) {
    errors.branch = 'Please enter an branch';
  }
   if (!formProps.accountType) {
    errors.accountType = 'Please enter an Account Type';
  }
   if (!formProps.accountNumber) {
    errors.accountNumber = 'Please enter your Account Number';
  }
   if (!formProps.bankName) {
    errors.bankName = 'Please enter an bank';
  }
   if (formProps.password != formProps.confpassword) {
    errors.confpassword = 'Password  does not match';
  }
  return errors;
}

class Register extends Component {  
  handleFormSubmit(formProps) {
    this.props.registerUser(formProps);
  }

  renderAlert() {
    if(this.props.errorMessage) {
      return (
        <div>
          <span><strong>Error!</strong> {this.props.errorMessage}</span>
        </div>
      );
    }
  }

  render() {
    const { handleSubmit } = this.props;

    return (
      <div className="overlay ">
      <form onSubmit={handleSubmit(this.handleFormSubmit.bind(this))} className="overlay-color-theme">
      {this.renderAlert()}
      <div className="row"  >
        <div className="col-md-6" >
        
          <label className="required form-font">Full Name</label>
          <Field name="firstName"  className="form-control  " component={renderField} type="text" />
        </div>   
        <div className="col-md-6">
            <label className="required form-font">Email</label> 
            <Field name="email" className="form-control" component={renderField} type="text" />
          </div>     
      </div>
         <div className="row">
          <div className="col-md-6">
            <label className="asterisk_input form-font">Branch</label>
            <Field name="branch" className="form-control" component = "select">
              <option value="">Select One</option>        
              <option value="kathmandu">Kathmandu</option>
              <option value="pokhara">Pokhara</option>
              <option value="chitwan">Chitwan</option>
              <option value="dharan">Dharan</option>
            </Field>
          </div>
           <div className="col-md-6">
            <label className="required form-font">Account Type</label>
            <Field name="accountType" className="form-control" component="select">
              <option value="">Select One</option>     
              <option value="A">A</option>
              <option value="B">B</option>
              <option value="C">C</option>       
            </Field>
          </div>
        </div>
        <div className="row">
         
        </div>       
        <div className="row">
          <div className="col-md-6">
            <label className="required form-font">Bank Name</label>
            <Field name="bankName" className="form-control" component={renderField} type="text" />
          </div>
          <div className="col-md-6">
            <label className="required form-font">Branch of Bank</label>
            <Field name="bankBranch" className="form-control" component={renderField} type="text" />
          </div>
        </div>
        <div className="row">
          
        </div>
        <div className="row">
          <div className="col-md-6">
            <label className="required form-font">Account Number</label>
            <Field name="accountNumber" className="form-control" component={renderField} type="text" />
          </div>
          <div className="col-md-6">
            <label className="required form-font">Contact</label>
            <Field name="contact" className="form-control" component={renderField} type="text" />
          </div>
        </div>
        <div className="row">
          <div className="col-md-6">
            <label className="required form-font">Password</label>
            <Field name="password" className="form-control" component={renderField} type="password" />
          </div>
           <div className="col-md-6">
            <label className="required form-font">Confirm Password</label>
            <Field name="confpassword" className="form-control" component={renderField} type="password" />
          </div>
        </div>
       <br>
       </br>
         <div className="row">         
        </div>
        <button type="submit" className="btn btn-primary">Register</button>
      </form>
      </div>
    );
  }
}

function mapStateToProps(state) {  
  console.log(state.auth);
  return {
    errorMessage: state.auth.error,
    message: state.auth.message
  };
}

export default connect(mapStateToProps, { registerUser })(form(Register)); 