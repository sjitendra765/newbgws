import React, { Component } from 'react';

class deposit extends Component {  
  render() {
    return (
      <div>Hello world! This is the home page route.</div>
    );
  }
}

export default deposit; 