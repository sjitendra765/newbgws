import React, { Component } from 'react';

class check extends Component {  
  render() {
    return (
      <div>Hello world! This is the home page route.</div>
    );
  }
}

export default check; 