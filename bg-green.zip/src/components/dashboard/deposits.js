import React, {Component } from 'react'
import { connect } from 'react-redux';
import { Link} from 'react-router';
import { Field, reduxForm } from 'redux-form'; 
import {depositUser} from '../../actions/admin';
import UserSearch from './UserSearch';
const CLIENT_ROOT_URL = 'http://localhost:3030';
const form = reduxForm({  
  form: 'Deposit'
});


class Deposit extends Component {
  constructor(props){
    super(props);

  }

  handleFormSubmit(formProps){    
      console.log("yaha ayo")
     // this.props.modalIsOpen = false;
    this.props.depositUser(formProps,this.props.params.id);
    
  }
  render(){
    const { handleSubmit } = this.props;
    return(

     
            
            <div className="col-md-4">
            <h3> Deposit </h3>
            <form className="form-group" onSubmit={handleSubmit(this.handleFormSubmit.bind(this))} > 
              <div className="form-group">
            Enter Your amount to Deposit : <Field component="input" name="amount"  />
            </div>
            
          <button className="btn btn-success" type="submit">Submit</button>
          </form>
           </div>
            
            

      );
  }
}

function mapStateToProps(state) {
  
  
  return {
    
    
  };
}

export default connect(mapStateToProps, { depositUser})(form(Deposit));