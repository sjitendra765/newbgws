import React ,{ Component} from 'react'
import { connect } from 'react-redux';
import { reportByBank,reportByBranch} from '../../actions/admin';
import CsvDownloader from 'react-csv-downloader';

class Report extends Component {
	constructor(props){
		super()
		this.state={
			rep :false,
			reports : ''
		}
	}
	byBranch(){
		this.props.reportByBranch();
		//console.log(this.props.report);
		//this.setState({reports : this.props.user})
		this.setState({rep:true})
	}
	componentWillReceiveProps(nextProps){
		this.setState({reports : nextProps.user})
	}
	byBank(){
		this.props.reportByBank();
		this.setState({rep:true})
	}
	demo(){
		console.log(this.props.user)

	}
	render(){
		const columns = [{
			  id: 'firstName',
			  displayName: 'Name'
			}, {
			  id: 'email',
			  displayName: 'Email'
			},{

			  id: 'contact',
			  displayName: 'Contact'
			},{

			  id: 'accountType',
			  displayName: 'Email'
			},{

			  id: 'accountNumber',
			  displayName: 'Account Type'
			},{

			  id: 'bankName',
			  displayName: 'Bank Name'
			},{

			  id: 'branchName',
			  displayName: 'Branch Name'
			},{

			  id: 'balance',
			  displayName: 'Balance'
			}];
			
			const datas = this.state.reports;
			
		const rep = this.state.rep;
		let report = null;
		if(rep){
			
			report =  <div>
      <CsvDownloader
        filename="report"
        separator=","
        columns={columns}
        datas={datas}
        text="DOWNLOAD" />
    </div>;
		}
		return(
				<div className="row">
					<div>
						<button className="btn btn-primary" onClick={this.byBranch.bind(this)}>Generate By Branch</button>
						<button className="btn btn-primary" onClick={this.byBank.bind(this)}>Generate By Bank </button>
					</div>
					
					{report}
				</div>
			)
	}
}

function mapStateToProps(state) {
	
  return {
    	user : state.admin.report
  };
}

export default connect(mapStateToProps, { reportByBank,reportByBranch })(Report);