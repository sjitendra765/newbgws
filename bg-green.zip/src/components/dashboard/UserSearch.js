import React, {Component } from 'react'
import { connect } from 'react-redux';
import { Field, reduxForm } from 'redux-form'; 
import {Link} from "react-router";
var Modal = require('react-modal');
import { searchUser , getUser , blockUser ,suspendUser} from '../../actions/UserSearch'

const form = reduxForm({
	form: 'UserSearch'
});

const customStyles = {
  content : {
    top                   : '50%',
    left                  : '50%',
    right                 : 'auto',
    bottom                : 'auto',
    marginRight           : '-50%',
    transform             : 'translate(-50%, -50%)'
  }
};



class UserSearch extends Component{
	constructor(props){
		super();
		this.state={
	      modalIsOpen : false,
	      viewModal : '',
	      id1:'',
	      block: ''
	    }
	}


	viewUserList(formProps) {
    this.props.searchUser(formProps)
    
  }
  viewUser(){
  	
  }
  editUser(id){
  	this.props.getUser(id)
  }

   openModal(test,text) {    
   	  this.setState({modalIsOpen: true,
      viewModal: test._id,
  	  id1 : test._id,
  	  block: test.blocked ? 'unblock' : 'block'	});  
    console.log(this.state.block); 
    
  }
  openModal1(test) {    
   	  this.setState({modalIsOpen: true,
      viewModal: test._id,
  	  id1 : test._id,
  	  block: test.blocked ? 'unsuspend' : 'suspend'	});  
    console.log(this.state.block);
  }
  setBlockValue(){
  		this.setState({modalIsOpen: false
  			});
  		console.log('block value',this.state.id1);
  		
  		if (this.state.block == 'block' || this.state.block == 'unblock')	{
  			this.props.blockUser(this.state.id1);
  		}	else if (this.state.block == 'suspend' || this.state.block == 'unsuspend'){
  			this.props.suspendUser(this.state.id1);
  		}
  		 
  		  
  }
  closeModal() {
    this.setState({modalIsOpen: false});
  }

  componentWillReceiveProps(nextProps){
  	this.props.user = nextProps.user;
  	
  }
	render(){
		let block = "";
		const { handleSubmit } = this.props;
		const test = this.state.viewModal;
		let popUp = null;
		 {popUp = <Modal
         isOpen={this.state.modalIsOpen}
          onRequestClose={this.closeModal.bind(this)}
           style={customStyles}
          contentLabel="Example Modal">
          Are you sure you want to {this.state.block} this user?
        
            <button className="btn btn-info" onClick={this.setBlockValue.bind(this)}>Yes</button>
			<button className="btn btn-info" onClick={this.closeModal.bind(this)}>Cancel</button>
           </Modal>;}
          
		return(
		<div>
				<form onSubmit = {handleSubmit(this.viewUserList.bind(this))} className="form-inline">
				
					
					<div className="form-group">
            
            <Field name="searchPara" className="form-control" component="input" type="text" />
          			</div>
          			<div className="form-group">
					 <Field name="searchBy" className="form-control" component="select" type="text" >
						<option value="searchByName">For Name</option>
						<option value="searchByBranch">For Branch</option>
						<option value="searchByBank">For Bank</option>
					</Field>
					</div>
					<button className="btn btn-success" type="submit">Search</button>
					</form>
					<div>
		 			<table className="table">
				<tr>
					<th>Name</th>
					<th>Contact</th>
					<th>Branch</th>
					<th>Bank Name</th>
					<th>Account Number</th>
					<th>Branch Of Bank</th>
					<th>Suspended Status</th>
					
				</tr>
				{
		 				this.props.user.map(u =>
		 					 <tr>
		 					

				
		 				
					<td>{u.firstName}</td>
					<td>{u.contact}</td>
					<td>{u.branch}</td>
					<td>{u.bankName}</td>
					<td>{u.accountNumber}</td>
					<td>{u.bankBranch}</td>
					<td>{u.suspended.toString()}</td>
					
					<td><button className="btn btn-info"><a href={`/dashboard/userprofile/${u._id}`}>View</a></button>
						 <button className="btn btn-success" ><a href={`/dashboard/editprofile/${u._id}`}>Edit</a></button>
						 <button className="btn btn-danger" onClick={this.openModal.bind(this,u)}>{u.blocked ? 'Unblock' : 'Block' }</button>
						 <button className="btn btn-danger" onClick={this.openModal1.bind(this,u)}>{u.suspended ? 'Unsuspend' : 'Suspend' }</button></td>


				</tr>
				)
		 			}

				</table>
		 		 </div>
				{popUp}
				</div>
			)
	}
}

function mapStateToProps(state) {
	
  return {
    user: state.user.user,
    profile:state.profile.user
  };
}

export default connect(mapStateToProps, { searchUser, getUser ,blockUser ,suspendUser})(form(UserSearch));