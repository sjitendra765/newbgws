import React, { Component } from 'react';

class App extends Component {  
  render() {
    return (
      <div>
      <div className="jumbotron" >
        <h1>British Gurkha Welfare Scheme</h1>
      </div>

      <div className="container">
       {this.props.children}
      </div>

      <footer className="footer">
      <div className="container">
        <p className="text-muted">@copyright 2016</p>
      </div>
    </footer>
      </div>
    );
  }
}

export default App;  