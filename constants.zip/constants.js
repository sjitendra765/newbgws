const ROLE_MEMBER = 'Member';

const ROLE_ADMIN = 'Admin';

module.exports = {
  ROLE_MEMBER,  
  ROLE_ADMIN
};
